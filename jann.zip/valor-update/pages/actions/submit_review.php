<?php
// actions/submit_review.php
session_start();
require_once '../config.php';
require_once '../dao/review_dao.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Please login first']);
    exit();
}

// Get form data
$product_id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : null;
$rating = isset($_POST['rating']) ? (int)$_POST['rating'] : null;
$review_text = isset($_POST['review_text']) ? trim($_POST['review_text']) : '';

// Validate input
if (!$product_id) {
    echo json_encode(['success' => false, 'message' => 'Product ID is required']);
    exit();
}

if (!$rating || $rating < 1 || $rating > 5) {
    echo json_encode(['success' => false, 'message' => 'Please select a rating between 1 and 5']);
    exit();
}

if (empty($review_text)) {
    echo json_encode(['success' => false, 'message' => 'Review text is required']);
    exit();
}

if (strlen($review_text) < 10) {
    echo json_encode(['success' => false, 'message' => 'Review must be at least 10 characters long']);
    exit();
}

if (strlen($review_text) > 1000) {
    echo json_encode(['success' => false, 'message' => 'Review must not exceed 1000 characters']);
    exit();
}

$reviewDAO = new ReviewDAO($db);
$user_id = $_SESSION['user_id'];

// Check if user already reviewed this product
if ($reviewDAO->hasUserReviewed($user_id, $product_id)) {
    echo json_encode(['success' => false, 'message' => 'You have already reviewed this product']);
    exit();
}

// Create the review
$result = $reviewDAO->createReview($user_id, $product_id, $rating, $review_text);

if ($result) {
    echo json_encode([
        'success' => true, 
        'message' => 'Review submitted successfully'
    ]);
} else {
    echo json_encode([
        'success' => false, 
        'message' => 'Failed to submit review. Please try again.'
    ]);
}
?>