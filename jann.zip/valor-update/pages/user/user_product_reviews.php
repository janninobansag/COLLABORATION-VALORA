<?php
// pages/user/user_product_reviews.php
session_start();
require_once '../../config.php';
require_once '../../dao/product_dao.php';
require_once '../../dao/review_dao.php';

// Get product ID from URL
$product_id = isset($_GET['product_id']) ? (int)$_GET['product_id'] : null;

if (!$product_id) {
    header('Location: user_shop_page.php');
    exit();
}

$productDAO = new ProductDAO($db);
$reviewDAO = new ReviewDAO($db);

// Get product details
$product = $productDAO->getProductById($product_id);

if (!$product) {
    header('Location: user_shop_page.php');
    exit();
}

// Get all reviews for this product
$reviews = $reviewDAO->getProductReviews($product_id);

// Calculate average rating
$averageRating = $reviewDAO->getAverageRating($product_id);
$totalReviews = count($reviews);

// Check if user has already reviewed this product
$userHasReviewed = false;
if (isset($_SESSION['user_id'])) {
    $userHasReviewed = $reviewDAO->hasUserReviewed($_SESSION['user_id'], $product_id);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Reviews - <?php echo htmlspecialchars($product['name']); ?> - Valora</title>

  <link rel="shortcut icon" href="../../favicon.svg" type="image/svg+xml">
  <link rel="stylesheet" href="../../assets/css/style.css">
  <link rel="stylesheet" href="../../assets/css/shop.css">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Urbanist:wght@400;500;600;700;800&display=swap" rel="stylesheet">

  <style>
    .reviews-container {
      max-width: 1200px;
      margin: 40px auto;
      padding: 0 20px;
    }

    .page-header {
      text-align: center;
      margin-bottom: 40px;
      padding-top: 40px;
    }

    .page-header h1 {
      font-size: 2rem;
      color: var(--gray-web);
      margin-bottom: 10px;
    }

    .product-info-card {
      background: white;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 2px 8px var(--black_10);
      margin-bottom: 40px;
      display: flex;
      gap: 30px;
      align-items: center;
    }

    .product-image-review {
      width: 150px;
      height: 150px;
      object-fit: cover;
      border-radius: 12px;
      flex-shrink: 0;
    }

    .product-details-review {
      flex: 1;
    }

    .product-name-review {
      font-size: 1.5rem;
      font-weight: 700;
      color: var(--gray-web);
      margin-bottom: 10px;
    }

    .product-category-review {
      color: var(--spanish-gray);
      text-transform: uppercase;
      font-size: 0.9rem;
      margin-bottom: 15px;
    }

    .rating-summary {
      background: var(--cultured-1);
      padding: 25px;
      border-radius: 12px;
      margin-bottom: 40px;
      text-align: center;
    }

    .average-rating {
      font-size: 3rem;
      font-weight: 700;
      color: var(--hoockers-green);
      margin-bottom: 10px;
    }

    .stars-large {
      font-size: 2rem;
      color: #fbbf24;
      margin-bottom: 10px;
    }

    .total-reviews {
      color: var(--spanish-gray);
      font-size: 1rem;
    }

    .review-form-section {
      background: white;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 2px 8px var(--black_10);
      margin-bottom: 40px;
    }

    .review-form-section h2 {
      font-size: 1.5rem;
      color: var(--gray-web);
      margin-bottom: 20px;
    }

    .form-group {
      margin-bottom: 20px;
    }

    .form-group label {
      display: block;
      font-weight: 600;
      color: var(--gray-web);
      margin-bottom: 8px;
    }

    .rating-input {
      display: flex;
      gap: 10px;
      flex-direction: row-reverse;
      justify-content: flex-end;
      font-size: 2rem;
    }

    .rating-input input {
      display: none;
    }

    .rating-input label {
      cursor: pointer;
      color: var(--light-gray);
      transition: color 0.2s;
    }

    .rating-input input:checked ~ label,
    .rating-input label:hover,
    .rating-input label:hover ~ label {
      color: #fbbf24;
    }

    .form-control {
      width: 100%;
      padding: 12px;
      border: 1px solid var(--light-gray);
      border-radius: 8px;
      font-size: 1rem;
      font-family: inherit;
      transition: border-color 0.3s;
    }

    .form-control:focus {
      outline: none;
      border-color: var(--hoockers-green);
    }

    textarea.form-control {
      min-height: 120px;
      resize: vertical;
    }

    .btn-submit-review {
      background: var(--hoockers-green);
      color: white;
      padding: 12px 30px;
      border: none;
      border-radius: 8px;
      font-size: 1rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
    }

    .btn-submit-review:hover {
      opacity: 0.9;
      transform: translateY(-2px);
      box-shadow: 0 4px 12px var(--hoockers-green_20);
    }

    .reviews-list {
      display: flex;
      flex-direction: column;
      gap: 20px;
    }

    .review-card {
      background: white;
      padding: 25px;
      border-radius: 12px;
      box-shadow: 0 2px 8px var(--black_10);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .review-card:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 16px var(--black_15);
    }

    .review-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 15px;
    }

    .reviewer-info {
      display: flex;
      align-items: center;
      gap: 15px;
    }

    .reviewer-avatar {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      background: var(--hoockers-green);
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.2rem;
      font-weight: 600;
    }

    .reviewer-details h3 {
      font-size: 1.1rem;
      font-weight: 600;
      color: var(--gray-web);
      margin-bottom: 5px;
    }

    .review-date {
      font-size: 0.9rem;
      color: var(--spanish-gray);
    }

    .review-rating {
      display: flex;
      gap: 3px;
      color: #fbbf24;
      font-size: 1.2rem;
    }

    .review-content {
      color: var(--gray-web);
      line-height: 1.6;
      margin-top: 15px;
    }

    .empty-reviews {
      text-align: center;
      padding: 60px 20px;
      background: white;
      border-radius: 12px;
      box-shadow: 0 2px 8px var(--black_10);
    }

    .empty-reviews ion-icon {
      font-size: 60px;
      color: var(--spanish-gray);
      margin-bottom: 15px;
    }

    .empty-reviews h3 {
      font-size: 1.3rem;
      color: var(--gray-web);
      margin-bottom: 10px;
    }

    .empty-reviews p {
      color: var(--spanish-gray);
    }

    .login-prompt {
      background: var(--cultured-1);
      padding: 20px;
      border-radius: 8px;
      text-align: center;
      margin-bottom: 40px;
    }

    .login-prompt p {
      margin-bottom: 15px;
      color: var(--gray-web);
    }

    .btn-login {
      background: var(--hoockers-green);
      color: white;
      padding: 10px 25px;
      border-radius: 8px;
      text-decoration: none;
      display: inline-block;
      font-weight: 600;
      transition: all 0.3s ease;
    }

    .btn-login:hover {
      opacity: 0.9;
      transform: translateY(-2px);
    }

    .already-reviewed {
      background: var(--cultured-1);
      padding: 20px;
      border-radius: 8px;
      text-align: center;
      color: var(--gray-web);
      margin-bottom: 40px;
    }

    @media (max-width: 768px) {
      .product-info-card {
        flex-direction: column;
        text-align: center;
      }

      .product-image-review {
        width: 100%;
        max-width: 200px;
        height: 200px;
      }

      .review-header {
        flex-direction: column;
        gap: 10px;
      }
    }
  </style>
</head>

<body id="top">

  <!-- Include Header/Navbar -->
  <?php include '../../includes/user_header.php'; ?>

  <!-- Include Mobile Sidebar -->
  <?php include '../../includes/user_sidebar.php'; ?>

  <main>
    <article>

      <div class="reviews-container">
        <div class="page-header">
          <h1>Product Reviews</h1>
        </div>

        <!-- Product Info Card -->
        <div class="product-info-card">
          <?php 
          $imagePath = $product['image_path'];
          if ($imagePath) {
              $imagePath = preg_replace('/^\.\.\/+/', '', $imagePath);
              $imageUrl = '../../' . $imagePath;
          }
          ?>
          <?php if ($imagePath && file_exists($imageUrl)): ?>
            <img src="<?php echo htmlspecialchars($imageUrl); ?>" 
                 alt="<?php echo htmlspecialchars($product['name']); ?>" 
                 class="product-image-review">
          <?php else: ?>
            <div class="product-image-review" style="background: var(--hoockers-green); display: flex; align-items: center; justify-content: center; color: white;">
              No Image
            </div>
          <?php endif; ?>
          
          <div class="product-details-review">
            <div class="product-category-review"><?php echo strtoupper($product['category']); ?></div>
            <h2 class="product-name-review"><?php echo htmlspecialchars($product['name']); ?></h2>
            <p style="color: var(--spanish-gray); margin-top: 10px;">
              <?php echo htmlspecialchars(substr($product['description'], 0, 150)) . '...'; ?>
            </p>
          </div>
        </div>

        <!-- Rating Summary -->
        <div class="rating-summary">
          <div class="average-rating">
            <?php echo number_format($averageRating, 1); ?>
          </div>
          <div class="stars-large">
            <?php 
            for ($i = 1; $i <= 5; $i++) {
              if ($i <= floor($averageRating)) {
                echo '<ion-icon name="star"></ion-icon>';
              } elseif ($i - 0.5 <= $averageRating) {
                echo '<ion-icon name="star-half"></ion-icon>';
              } else {
                echo '<ion-icon name="star-outline"></ion-icon>';
              }
            }
            ?>
          </div>
          <div class="total-reviews">Based on <?php echo $totalReviews; ?> review<?php echo $totalReviews != 1 ? 's' : ''; ?></div>
        </div>

        <!-- Review Form -->
        <?php if (isset($_SESSION['user_id'])): ?>
          <?php if (!$userHasReviewed): ?>
            <div class="review-form-section">
              <h2>Write a Review</h2>
              <form id="reviewForm">
                <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
                
                <div class="form-group">
                  <label>Your Rating *</label>
                  <div class="rating-input">
                    <input type="radio" name="rating" id="star5" value="5" required>
                    <label for="star5"><ion-icon name="star"></ion-icon></label>
                    
                    <input type="radio" name="rating" id="star4" value="4">
                    <label for="star4"><ion-icon name="star"></ion-icon></label>
                    
                    <input type="radio" name="rating" id="star3" value="3">
                    <label for="star3"><ion-icon name="star"></ion-icon></label>
                    
                    <input type="radio" name="rating" id="star2" value="2">
                    <label for="star2"><ion-icon name="star"></ion-icon></label>
                    
                    <input type="radio" name="rating" id="star1" value="1">
                    <label for="star1"><ion-icon name="star"></ion-icons></label>
                  </div>
                </div>

                <div class="form-group">
                  <label for="reviewText">Your Review *</label>
                  <textarea 
                    class="form-control" 
                    id="reviewText" 
                    name="review_text" 
                    placeholder="Share your experience with this product..." 
                    required
                    minlength="10"
                    maxlength="1000"></textarea>
                </div>

                <button type="submit" class="btn-submit-review">Submit Review</button>
              </form>
            </div>
          <?php else: ?>
            <div class="already-reviewed">
              <p><strong>You've already reviewed this product.</strong></p>
              <p>Thank you for your feedback!</p>
            </div>
          <?php endif; ?>
        <?php else: ?>
          <div class="login-prompt">
            <p><strong>Please login to write a review</strong></p>
            <a href="../login.php" class="btn-login">Login Now</a>
          </div>
        <?php endif; ?>

        <!-- Reviews List -->
        <h2 style="font-size: 1.5rem; color: var(--gray-web); margin-bottom: 20px;">Customer Reviews</h2>
        
        <?php if (!empty($reviews)): ?>
          <div class="reviews-list">
            <?php foreach ($reviews as $review): ?>
              <div class="review-card">
                <div class="review-header">
                  <div class="reviewer-info">
                    <div class="reviewer-avatar">
                      <?php echo strtoupper(substr($review['username'], 0, 1)); ?>
                    </div>
                    <div class="reviewer-details">
                      <h3><?php echo htmlspecialchars($review['username']); ?></h3>
                      <div class="review-date">
                        <?php echo date('F j, Y', strtotime($review['created_at'])); ?>
                      </div>
                    </div>
                  </div>
                  <div class="review-rating">
                    <?php 
                    for ($i = 1; $i <= 5; $i++) {
                      if ($i <= $review['rating']) {
                        echo '<ion-icon name="star"></ion-icon>';
                      } else {
                        echo '<ion-icon name="star-outline"></ion-icon>';
                      }
                    }
                    ?>
                  </div>
                </div>
                <div class="review-content">
                  <?php echo nl2br(htmlspecialchars($review['review_text'])); ?>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php else: ?>
          <div class="empty-reviews">
            <ion-icon name="chatbubbles-outline"></ion-icon>
            <h3>No Reviews Yet</h3>
            <p>Be the first to review this product!</p>
          </div>
        <?php endif; ?>

      </div>

    </article>
  </main>

  <!-- Include Footer -->
  <?php include '../../includes/footer.php'; ?>

  <!-- BACK TO TOP -->
  <a href="#top" class="back-top-btn" aria-label="back to top" data-back-top-btn>
    <ion-icon name="arrow-up" aria-hidden="true"></ion-icon>
  </a>

  <script src="../../assets/js/script.js" defer></script>
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

  <script>
    document.getElementById('reviewForm')?.addEventListener('submit', function(e) {
      e.preventDefault();
      
      const formData = new FormData(this);
      
      fetch('../../actions/submit_review.php', {
        method: 'POST',
        body: formData
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          alert('Review submitted successfully!');
          location.reload();
        } else {
          alert('Failed to submit review: ' + (data.message || 'Unknown error'));
        }
      })
      .catch(error => {
        console.error('Error:', error);
        alert('Failed to submit review. Please try again.');
      });
    });
  </script>

</body>
</html>