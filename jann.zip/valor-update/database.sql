-- Valora Database Schema
-- Create Database
CREATE DATABASE IF NOT EXISTS valora_db;
USE valora_db;

-- Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    phone VARCHAR(15),
    role ENUM('customer', 'admin') DEFAULT 'customer',
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Products Table
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    category ENUM('collection', 'dress', 'gown') NOT NULL,
    collection VARCHAR(100),
    image_path VARCHAR(255),
    stock_quantity INT DEFAULT 0,
    total_stock INT DEFAULT 0,
    available_stock INT DEFAULT 0,
    purchased_stock INT DEFAULT 0,
    is_active TINYINT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Cart Table
CREATE TABLE IF NOT EXISTS cart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- Orders Table
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'completed', 'cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Order Items Table
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- Insert sample admin user (password: admin123)
INSERT INTO users (username, email, password, first_name, last_name, role) 
VALUES ('admin', 'admin@valora.com', '$2y$10$YIjlrHpVZEDVztkWQEsDcOWd0/iiK1FujD5xKNAzOSVvQpKKXFpVu', 'Admin', 'User', 'admin');


INSERT INTO products (name, description, price, category, collection, image_path, stock_quantity) VALUES
('Summer Dress', 'Light and comfortable summer dress', 45.00, 'dress', 'Summer 2025', 'assets/images/dress/summer_dress.jpg', 20),
('Evening Gown', 'Elegant evening gown for special occasions', 150.00, 'gown', 'Evening Elegance', 'assets/images/gown/evening_gown.jpg', 10),
('Casual Collection', 'Casual wear collection for everyday', 35.00, 'collection', 'Casual 2025', 'assets/images/collection/casual.jpg', 30),
('Formal Gown', 'Sophisticated formal gown', 200.00, 'gown', 'Formal', 'assets/images/gown/formal_gown.jpg', 5),
('Golden Hour Tea Length Dress', 'Sophisticated tea-length dress with golden lace details perfect for fall ceremonies', 6499.00, 'dress', 'Fall Bridal', 'assets/images/products/golden-hour-dress.jpg', 18),

('Rustic Elegance Ball Gown', 'Luxurious ball gown with burgundy undertones and intricate beading', 13999.00, 'gown', 'Fall Bridal', 'assets/images/products/rustic-elegance-gown.jpg', 6),
('Harvest Moon Princess Gown', 'Romantic princess-style gown with champagne tulle and floral appliques', 11299.00, 'gown', 'Fall Bridal', 'assets/images/products/harvest-moon-gown.jpg', 8),


('Seaside Breeze Chiffon Dress', 'Light and flowing chiffon dress with delicate floral embroidery', 5999.00, 'dress', 'Summer Bridal', 'assets/images/products/seaside-breeze-dress.jpg', 22),
('Tropical Paradise Short Dress', 'Playful short wedding dress with tropical-inspired lace details', 4799.00, 'dress', 'Summer Bridal', 'assets/images/products/tropical-paradise-dress.jpg', 25),


('Sunset Beach Mermaid Gown', 'Stunning mermaid silhouette gown perfect for beach weddings', 9899.00, 'gown', 'Summer Bridal', 'assets/images/products/sunset-beach-gown.jpg', 10),
('Ocean Wave A-Line Gown', 'Flowing A-line gown with soft blue undertones and pearl details', 8599.00, 'gown', 'Summer Bridal', 'assets/images/products/ocean-wave-gown.jpg', 12),

('Modern Minimalist Slip Dress', 'Sleek silk slip dress with cowl neckline for contemporary brides', 5299.00, 'dress', 'Bridal Studio', 'assets/images/products/modern-slip-dress.jpg', 20),
('Classic Grace Tea Dress', 'Timeless tea-length dress with vintage-inspired lace overlay', 6899.00, 'dress', 'Bridal Studio', 'assets/images/products/classic-grace-dress.jpg', 16),

('Timeless Cathedral Gown', 'Traditional cathedral train gown with exquisite beadwork', 14999.00, 'gown', 'Bridal Studio', 'assets/images/products/timeless-cathedral-gown.jpg', 5),
('Regal Ballroom Gown', 'Majestic ballroom gown with off-shoulder design and crystal embellishments', 16499.00, 'gown', 'Bridal Studio', 'assets/images/products/regal-ballroom-gown.jpg', 4);

CREATE TABLE IF NOT EXISTS reviews (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    review_text TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    UNIQUE KEY unique_user_product (user_id, product_id)
);
