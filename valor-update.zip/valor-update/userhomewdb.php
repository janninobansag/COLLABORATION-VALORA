<?php
// user_home_page.php
session_start();
require_once '../config.php';
require_once '../dao/product_dao.php';

$productDAO = new ProductDAO($db);
$products = $productDAO->getAllProducts(true); // only active products

// Group products by category for better display
$productsByCategory = [
    'dress' => [],
    'gown' => [],
    'collection' => []
];

foreach ($products as $product) {
    if (isset($productsByCategory[$product['category']])) {
        $productsByCategory[$product['category']][] = $product;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Valora - Shop Premium Fashion</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            color: #333;
        }
        
        /* Header */
        .header {
            background-color: #2c3e50;
            color: white;
            padding: 20px 0;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .header-content {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo {
            font-size: 28px;
            font-weight: bold;
            letter-spacing: 2px;
        }
        
        .nav-links {
            display: flex;
            gap: 30px;
        }
        
        .nav-links a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            transition: color 0.3s;
        }
        
        .nav-links a:hover {
            color: #3498db;
        }
        
        /* Hero Section */
        .hero {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 60px 20px;
            text-align: center;
        }
        
        .hero h1 {
            font-size: 48px;
            margin-bottom: 20px;
        }
        
        .hero p {
            font-size: 20px;
            opacity: 0.9;
        }
        
        /* Container */
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 40px 20px;
        }
        
        /* Category Section */
        .category-section {
            margin-bottom: 60px;
        }
        
        .category-header {
            display: flex;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 3px solid #3498db;
        }
        
        .category-header h2 {
            font-size: 32px;
            color: #2c3e50;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .product-count {
            margin-left: 15px;
            background-color: #3498db;
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 14px;
        }
        
        /* Product Grid */
        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 30px;
        }
        
        .product-card {
            background-color: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: transform 0.3s, box-shadow 0.3s;
            cursor: pointer;
        }
        
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 12px rgba(0,0,0,0.15);
        }
        
        .product-image {
            width: 100%;
            height: 300px;
            object-fit: cover;
            background-color: #ecf0f1;
        }
        
        .product-image-placeholder {
            width: 100%;
            height: 300px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 18px;
        }
        
        .product-info {
            padding: 20px;
        }
        
        .product-name {
            font-size: 20px;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 10px;
        }
        
        .product-description {
            color: #7f8c8d;
            font-size: 14px;
            line-height: 1.5;
            margin-bottom: 15px;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        
        .product-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-top: 15px;
            border-top: 1px solid #ecf0f1;
        }
        
        .product-price {
            font-size: 24px;
            font-weight: bold;
            color: #27ae60;
        }
        
        .product-stock {
            font-size: 12px;
            padding: 5px 10px;
            border-radius: 5px;
        }
        
        .in-stock {
            background-color: #d5f4e6;
            color: #27ae60;
        }
        
        .low-stock {
            background-color: #fadbd8;
            color: #e74c3c;
        }
        
        .collection-badge {
            display: inline-block;
            background-color: #f3e5f5;
            color: #7b1fa2;
            padding: 5px 12px;
            border-radius: 15px;
            font-size: 12px;
            margin-bottom: 10px;
        }
        
        .empty-message {
            text-align: center;
            padding: 60px 20px;
            color: #7f8c8d;
        }
        
        .empty-message h3 {
            font-size: 24px;
            margin-bottom: 10px;
        }
        
        /* Footer */
        .footer {
            background-color: #2c3e50;
            color: white;
            text-align: center;
            padding: 30px 20px;
            margin-top: 60px;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .hero h1 {
                font-size: 32px;
            }
            
            .hero p {
                font-size: 16px;
            }
            
            .category-header h2 {
                font-size: 24px;
            }
            
            .product-grid {
                grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
                gap: 20px;
            }
            
            .nav-links {
                gap: 15px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="header-content">
            <div class="logo">VALORA</div>
            <div class="nav-links">
                <a href="user_home_page.php">Home</a>
                <a href="#">Shop</a>
                <a href="#">Cart</a>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="#">My Account</a>
                    <a href="../process/logout.php">Logout</a>
                <?php else: ?>
                    <a href="login.php">Login</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Hero Section -->
    <div class="hero">
        <h1>Welcome to Valora</h1>
        <p>Discover Premium Fashion Collections</p>
    </div>
    
    <!-- Main Content -->
    <div class="container">
        <?php if (empty($products)): ?>
            <div class="empty-message">
                <h3>No Products Available</h3>
                <p>Check back soon for new arrivals!</p>
            </div>
        <?php else: ?>
            
            <!-- Dresses Section -->
            <?php if (!empty($productsByCategory['dress'])): ?>
            <div class="category-section">
                <div class="category-header">
                    <h2>Dresses</h2>
                    <span class="product-count"><?php echo count($productsByCategory['dress']); ?> items</span>
                </div>
                <div class="product-grid">
                    <?php foreach ($productsByCategory['dress'] as $product): ?>
                    <div class="product-card">
                        <?php 
                        // Fix the image path - remove any '../' prefix if it exists
                        $imagePath = $product['image_path'];
                        if ($imagePath) {
                            // Remove '../' or '../../' from the beginning
                            $imagePath = preg_replace('/^\.\.\/+/', '', $imagePath);
                            $imageUrl = '../' . $imagePath;
                        }
                        ?>
                        
                        <?php if ($imagePath && file_exists($imageUrl)): ?>
                            <img src="<?php echo htmlspecialchars($imageUrl); ?>" 
                                 alt="<?php echo htmlspecialchars($product['name']); ?>" 
                                 class="product-image"
                                 onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                            <div class="product-image-placeholder" style="display: none;">
                                No Image
                            </div>
                        <?php else: ?>
                            <div class="product-image-placeholder">
                                No Image
                            </div>
                        <?php endif; ?>
                        
                        <div class="product-info">
                            <?php if (!empty($product['collection']) && $product['collection'] !== 'N/A'): ?>
                                <span class="collection-badge"><?php echo htmlspecialchars($product['collection']); ?></span>
                            <?php endif; ?>
                            
                            <div class="product-name"><?php echo htmlspecialchars($product['name']); ?></div>
                            <div class="product-description"><?php echo htmlspecialchars($product['description']); ?></div>
                            
                            <div class="product-footer">
                                <div class="product-price">₱<?php echo number_format($product['price'], 2); ?></div>
                                <div class="product-stock <?php echo $product['stock_quantity'] <= 5 ? 'low-stock' : 'in-stock'; ?>">
                                    <?php echo $product['stock_quantity']; ?> in stock
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Gowns Section -->
            <?php if (!empty($productsByCategory['gown'])): ?>
            <div class="category-section">
                <div class="category-header">
                    <h2>Gowns</h2>
                    <span class="product-count"><?php echo count($productsByCategory['gown']); ?> items</span>
                </div>
                <div class="product-grid">
                    <?php foreach ($productsByCategory['gown'] as $product): ?>
                    <div class="product-card">
                        <?php 
                        $imagePath = $product['image_path'];
                        if ($imagePath) {
                            $imagePath = preg_replace('/^\.\.\/+/', '', $imagePath);
                            $imageUrl = '../' . $imagePath;
                        }
                        ?>
                        
                        <?php if ($imagePath && file_exists($imageUrl)): ?>
                            <img src="<?php echo htmlspecialchars($imageUrl); ?>" 
                                 alt="<?php echo htmlspecialchars($product['name']); ?>" 
                                 class="product-image"
                                 onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                            <div class="product-image-placeholder" style="display: none;">
                                No Image
                            </div>
                        <?php else: ?>
                            <div class="product-image-placeholder">
                                No Image
                            </div>
                        <?php endif; ?>
                        
                        <div class="product-info">
                            <?php if (!empty($product['collection']) && $product['collection'] !== 'N/A'): ?>
                                <span class="collection-badge"><?php echo htmlspecialchars($product['collection']); ?></span>
                            <?php endif; ?>
                            
                            <div class="product-name"><?php echo htmlspecialchars($product['name']); ?></div>
                            <div class="product-description"><?php echo htmlspecialchars($product['description']); ?></div>
                            
                            <div class="product-footer">
                                <div class="product-price">₱<?php echo number_format($product['price'], 2); ?></div>
                                <div class="product-stock <?php echo $product['stock_quantity'] <= 5 ? 'low-stock' : 'in-stock'; ?>">
                                    <?php echo $product['stock_quantity']; ?> in stock
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Collections Section -->
            <?php if (!empty($productsByCategory['collection'])): ?>
            <div class="category-section">
                <div class="category-header">
                    <h2>Collections</h2>
                    <span class="product-count"><?php echo count($productsByCategory['collection']); ?> items</span>
                </div>
                <div class="product-grid">
                    <?php foreach ($productsByCategory['collection'] as $product): ?>
                    <div class="product-card">
                        <?php 
                        $imagePath = $product['image_path'];
                        if ($imagePath) {
                            $imagePath = preg_replace('/^\.\.\/+/', '', $imagePath);
                            $imageUrl = '../' . $imagePath;
                        }
                        ?>
                        
                        <?php if ($imagePath && file_exists($imageUrl)): ?>
                            <img src="<?php echo htmlspecialchars($imageUrl); ?>" 
                                 alt="<?php echo htmlspecialchars($product['name']); ?>" 
                                 class="product-image"
                                 onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                            <div class="product-image-placeholder" style="display: none;">
                                No Image
                            </div>
                        <?php else: ?>
                            <div class="product-image-placeholder">
                                No Image
                            </div>
                        <?php endif; ?>
                        
                        <div class="product-info">
                            <?php if (!empty($product['collection']) && $product['collection'] !== 'N/A'): ?>
                                <span class="collection-badge"><?php echo htmlspecialchars($product['collection']); ?></span>
                            <?php endif; ?>
                            
                            <div class="product-name"><?php echo htmlspecialchars($product['name']); ?></div>
                            <div class="product-description"><?php echo htmlspecialchars($product['description']); ?></div>
                            
                            <div class="product-footer">
                                <div class="product-price">₱<?php echo number_format($product['price'], 2); ?></div>
                                <div class="product-stock <?php echo $product['stock_quantity'] <= 5 ? 'low-stock' : 'in-stock'; ?>">
                                    <?php echo $product['stock_quantity']; ?> in stock
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
            
        <?php endif; ?>
    </div>
    
    <!-- Footer -->
    <div class="footer">
        <p>&copy; 2024 Valora. All rights reserved.</p>
    </div>
</body>
</html>