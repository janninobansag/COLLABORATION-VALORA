<?php
// pages/user_item.php
session_start();
require_once '../../config.php';
require_once '../../dao/product_dao.php';

// Get product ID from URL
$product_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($product_id <= 0) {
    header('Location: user_shop_page.php');
    exit();
}

$productDAO = new ProductDAO($db);
$product = $productDAO->getProductById($product_id);

if (!$product) {
    header('Location: user_shop_page.php');
    exit();
}

// Calculate discount percentage if there's a sale
$discount = 0;
$originalPrice = $product['price'] * 1.2; // Example: 20% markup for display
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($product['name']); ?> - Valora</title>
    
    <link rel="shortcut icon" href="../../favicon.svg" type="image/svg+xml">
    
    <!-- Base Styles -->
    <link rel="stylesheet" href="../../assets/css/style.css">
    
    <!-- Item Detail Specific Styles -->
    <link rel="stylesheet" href="../../assets/css/item.css">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Urbanist:wght@400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body id="top">
    <!-- Notification -->
    <div id="notification" class="item-notification">
        <span id="notificationText"></span>
    </div>

    <!-- Include Header/Navbar -->
    <?php include '../../includes/user_header.php'; ?>

    <!-- Include Mobile Sidebar -->
    <?php include '../../includes/user_sidebar.php'; ?>

    <main>
      <article>
        <!-- Product Detail -->
        <section class="section">
          <div class="item-container">
            <div class="item-detail">
              <!-- Image Gallery -->
              <div class="item-gallery">
                <div class="item-main-image">
                  <?php 
                  $imagePath = $product['image_path'];
                  if ($imagePath) {
                      $imagePath = preg_replace('/^\.\.\/+/', '', $imagePath);
                      $imageUrl = '../../' . $imagePath;
                  }
                  ?>
                  <?php if ($imagePath && file_exists($imageUrl)): ?>
                    <img id="mainImage" src="<?php echo htmlspecialchars($imageUrl); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                  <?php else: ?>
                    <div class="item-no-image">No Image Available</div>
                  <?php endif; ?>
                </div>

                <!-- Thumbnails -->
                <div class="item-thumbnail-grid">
                  <?php if ($imagePath && file_exists($imageUrl)): ?>
                    <div class="item-thumbnail active">
                      <img src="<?php echo htmlspecialchars($imageUrl); ?>" alt="View 1">
                    </div>
                    <div class="item-thumbnail">
                      <img src="<?php echo htmlspecialchars($imageUrl); ?>" alt="View 2">
                    </div>
                    <div class="item-thumbnail">
                      <img src="<?php echo htmlspecialchars($imageUrl); ?>" alt="View 3">
                    </div>
                    <div class="item-thumbnail">
                      <img src="<?php echo htmlspecialchars($imageUrl); ?>" alt="View 4">
                    </div>
                  <?php endif; ?>
                </div>
              </div>

              <!-- Product Information -->
              <div class="item-info">
                <div class="item-header">
                  <div class="item-category"><?php echo strtoupper($product['category']); ?></div>
                  <h1 class="item-title"><?php echo htmlspecialchars($product['name']); ?></h1>
                  <?php if (!empty($product['collection']) && $product['collection'] !== 'N/A'): ?>
                    <p class="item-collection"><?php echo htmlspecialchars($product['collection']); ?> Collection</p>
                  <?php endif; ?>
                  
                  <div class="item-rating-section">
                    <div class="item-stars">
                      ★★★★★
                    </div>
                    <span class="item-rating-text">4.8 (124 reviews)</span>
                  </div>
                </div>

                <div class="item-price-section">
                  <div class="item-price">₱<?php echo number_format($product['price'], 2); ?></div>
                  <div class="item-original-price">₱<?php echo number_format($originalPrice, 2); ?></div>
                </div>

                <div class="item-stock-info <?php echo $product['stock_quantity'] <= 5 ? 'low-stock' : ''; ?>">
                  <?php if ($product['stock_quantity'] > 0): ?>
                    <?php echo $product['stock_quantity']; ?> in stock
                  <?php else: ?>
                    Out of stock
                  <?php endif; ?>
                </div>

                <div class="item-description">
                  <?php echo nl2br(htmlspecialchars($product['description'])); ?>
                </div>

                <!-- Color Variant -->
                <div class="item-variant-section">
                  <div class="item-variant-label">Select Color</div>
                  <div class="item-color-options">
                    <div class="item-color-option active" style="background: #FFFFF0;" data-color="Ivory White" title="Ivory White"></div>
                    <div class="item-color-option" style="background: #FFE4E1;" data-color="Blush Pink" title="Blush Pink"></div>
                    <div class="item-color-option" style="background: #FFFDD0;" data-color="Cream" title="Cream"></div>
                    <div class="item-color-option" style="background: linear-gradient(135deg, #FFD700, #FFA500);" data-color="Golden" title="Golden"></div>
                  </div>
                </div>

                <!-- Size Variant -->
                <div class="item-variant-section">
                  <div class="item-variant-label">Select Size</div>
                  <div class="item-variant-options">
                    <div class="item-variant-option" data-size="XS">XS</div>
                    <div class="item-variant-option active" data-size="S">S</div>
                    <div class="item-variant-option" data-size="M">M</div>
                    <div class="item-variant-option" data-size="L">L</div>
                    <div class="item-variant-option" data-size="XL">XL</div>
                  </div>
                </div>

                <!-- Quantity -->
                <div class="item-variant-section">
                  <div class="item-variant-label">Quantity</div>
                  <div class="item-quantity-section">
                    <div class="item-quantity-control">
                      <button class="item-qty-btn" id="decreaseQty">−</button>
                      <input type="number" id="quantity" class="item-qty-input" value="1" min="1" max="<?php echo $product['stock_quantity']; ?>" readonly>
                      <button class="item-qty-btn" id="increaseQty">+</button>
                    </div>
                  </div>
                </div>

                <!-- Action Buttons -->
                <div class="item-action-buttons">
                  <button class="item-btn item-btn-primary" id="addToCartBtn" data-product-id="<?php echo $product['id']; ?>">
                    <ion-icon name="bag-handle-outline"></ion-icon>
                    Add to Cart
                  </button>
                  <button class="item-btn item-btn-secondary">
                    <ion-icon name="flash-outline"></ion-icon>
                    Buy Now
                  </button>
                  <button class="item-btn item-btn-icon">
                    <ion-icon name="heart-outline"></ion-icon>
                  </button>
                </div>

                <!-- Product Details -->
                <div class="item-details-section">
                  <div class="item-variant-label">Product Details</div>
                  <div class="item-details-grid">
                    <div class="item-detail-item">
                      <div class="item-detail-label">Fabric</div>
                      <div class="item-detail-value">Premium Satin & Lace</div>
                    </div>
                    <div class="item-detail-item">
                      <div class="item-detail-label">Care Instructions</div>
                      <div class="item-detail-value">Dry Clean Only</div>
                    </div>
                    <div class="item-detail-item">
                      <div class="item-detail-label">Category</div>
                      <div class="item-detail-value"><?php echo ucfirst($product['category']); ?></div>
                    </div>
                    <div class="item-detail-item">
                      <div class="item-detail-label">Product ID</div>
                      <div class="item-detail-value">#VAL-<?php echo str_pad($product['id'], 4, '0', STR_PAD_LEFT); ?></div>
                    </div>
                  </div>
                </div>

                <!-- Features -->
                <div class="item-features">
                  <div class="item-feature">
                    <div class="item-feature-icon">
                      <ion-icon name="gift-outline"></ion-icon>
                    </div>
                    <div class="item-feature-text">Free Shipping<br>over ₱5,000</div>
                  </div>
                  <div class="item-feature">
                    <div class="item-feature-icon">
                      <ion-icon name="shield-checkmark-outline"></ion-icon>
                    </div>
                    <div class="item-feature-text">Quality<br>Guaranteed</div>
                  </div>
                  <div class="item-feature">
                    <div class="item-feature-icon">
                      <ion-icon name="repeat-outline"></ion-icon>
                    </div>
                    <div class="item-feature-text">Easy Returns<br>within 30 days</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </article>
    </main>

    <!-- Include Footer -->
    <?php include '../../includes/footer.php'; ?>

    <!-- BACK TO TOP -->
    <a href="#top" class="back-top-btn" aria-label="back to top" data-back-top-btn>
      <ion-icon name="arrow-up" aria-hidden="true"></ion-icon>
    </a>

    <!-- Scripts -->
    <script src="../../assets/js/script.js" defer></script>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <script src="../../assets/js/cart.js"></script>
    
    // Replace the script section in user_item.php with this enhanced version

<script>
    // Quantity Controls
    const qtyInput = document.getElementById('quantity');
    const increaseBtn = document.getElementById('increaseQty');
    const decreaseBtn = document.getElementById('decreaseQty');
    const maxStock = <?php echo $product['stock_quantity']; ?>;

    increaseBtn.addEventListener('click', () => {
        let currentQty = parseInt(qtyInput.value);
        if (currentQty < maxStock) {
            qtyInput.value = currentQty + 1;
        } else {
            showNotification('Maximum stock reached', 'error');
        }
    });

    decreaseBtn.addEventListener('click', () => {
        let currentQty = parseInt(qtyInput.value);
        if (currentQty > 1) {
            qtyInput.value = currentQty - 1;
        }
    });

    // Color Selection
    document.querySelectorAll('.item-color-option').forEach(option => {
        option.addEventListener('click', function() {
            document.querySelectorAll('.item-color-option').forEach(o => o.classList.remove('active'));
            this.classList.add('active');
        });
    });

    // Size Selection
    document.querySelectorAll('.item-variant-option').forEach(option => {
        option.addEventListener('click', function() {
            const parent = this.parentElement;
            parent.querySelectorAll('.item-variant-option').forEach(o => o.classList.remove('active'));
            this.classList.add('active');
        });
    });

    // Add to Cart - Uses the function from cart.js
    document.getElementById('addToCartBtn').addEventListener('click', function() {
        const productId = this.getAttribute('data-product-id');
        const quantity = parseInt(qtyInput.value);
        
        if (quantity > maxStock) {
            showNotification('Not enough stock available', 'error');
            return;
        }
        
        if (quantity < 1) {
            showNotification('Please select at least 1 item', 'error');
            return;
        }

        // Check if user is logged in (you can add this check)
        <?php if (!isset($_SESSION['user_id'])): ?>
            showNotification('Please login to add items to cart', 'error');
            setTimeout(() => {
                window.location.href = '../auth/login.php';
            }, 1500);
            return;
        <?php endif; ?>

        // Call the addToCart function from cart.js
        addToCart(productId, quantity);
    });

    // Thumbnail click
    document.querySelectorAll('.item-thumbnail').forEach(thumb => {
        thumb.addEventListener('click', function() {
            document.querySelectorAll('.item-thumbnail').forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            const img = this.querySelector('img');
            if (img) {
                document.getElementById('mainImage').src = img.src;
            }
        });
    });

    // Note: showNotification function is now imported from cart.js
    // If it's not working, you can uncomment this fallback:
    /*
    function showNotification(message, type = 'success') {
        const notification = document.getElementById('notification');
        const notificationText = document.getElementById('notificationText');
        
        if (notification && notificationText) {
            notificationText.textContent = message;
            notification.className = `item-notification ${type} show`;
            
            setTimeout(() => {
                notification.classList.remove('show');
            }, 3000);
        }
    }
    */
</script>
</body>
</html>