-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 02, 2025 at 07:39 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `valora_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `status` enum('pending','completed','cancelled') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `total_amount`, `status`, `created_at`, `updated_at`) VALUES
(1, 2, 25297.00, 'completed', '2025-12-02 05:09:39', '2025-12-02 05:10:39'),
(2, 2, 545.00, 'completed', '2025-12-02 05:37:15', '2025-12-02 05:44:14'),
(3, 2, 545.00, 'completed', '2025-12-02 05:58:56', '2025-12-02 05:59:30'),
(4, 2, 5299.00, 'pending', '2025-12-02 06:03:39', '2025-12-02 06:03:39'),
(5, 2, 545.00, 'pending', '2025-12-02 06:05:38', '2025-12-02 06:05:38');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `price`) VALUES
(1, 1, 4, 1, 200.00),
(2, 1, 7, 1, 11299.00),
(3, 1, 13, 2, 6899.00),
(4, 2, 1, 1, 45.00),
(5, 3, 1, 1, 45.00),
(6, 4, 9, 1, 4799.00),
(7, 5, 1, 1, 45.00);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `category` enum('collection','dress','gown') NOT NULL,
  `collection` varchar(100) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `stock_quantity` int(11) DEFAULT 0,
  `is_active` tinyint(4) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `category`, `collection`, `image_path`, `stock_quantity`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Summer Dress', 'Light and comfortable summer dress', 45.00, 'dress', 'Bridal Studio', 'assets/images/dress/692e7ad60943b_fallgown1.jpg', 15, 1, '2025-12-02 04:29:59', '2025-12-02 06:05:38'),
(2, 'Evening Gown', 'Elegant evening gown for special occasions', 150.00, 'gown', 'Evening Elegance', 'assets/images/gown/evening_gown.jpg', 10, 1, '2025-12-02 04:29:59', '2025-12-02 04:29:59'),
(3, 'Casual Collection', 'Casual wear collection for everyday', 35.00, 'collection', 'Casual 2025', 'assets/images/collection/casual.jpg', 30, 1, '2025-12-02 04:29:59', '2025-12-02 04:29:59'),
(4, 'Formal Gown', 'Sophisticated formal gown', 200.00, 'gown', 'Formal', 'assets/images/gown/formal_gown.jpg', 4, 1, '2025-12-02 04:29:59', '2025-12-02 05:09:39'),
(5, 'Golden Hour Tea Length Dress', 'Sophisticated tea-length dress with golden lace details perfect for fall ceremonies', 6499.00, 'dress', 'Fall Bridal', 'assets/images/products/golden-hour-dress.jpg', 18, 1, '2025-12-02 04:29:59', '2025-12-02 04:29:59'),
(6, 'Rustic Elegance Ball Gown', 'Luxurious ball gown with burgundy undertones and intricate beading', 13999.00, 'gown', 'Fall Bridal', 'assets/images/products/rustic-elegance-gown.jpg', 6, 1, '2025-12-02 04:29:59', '2025-12-02 04:29:59'),
(7, 'Harvest Moon Princess Gown', 'Romantic princess-style gown with champagne tulle and floral appliques', 11299.00, 'gown', 'Fall Bridal', 'assets/images/products/harvest-moon-gown.jpg', 7, 1, '2025-12-02 04:29:59', '2025-12-02 05:09:39'),
(8, 'Seaside Breeze Chiffon Dress', 'Light and flowing chiffon dress with delicate floral embroidery', 5999.00, 'dress', 'Summer Bridal', 'assets/images/products/seaside-breeze-dress.jpg', 22, 1, '2025-12-02 04:29:59', '2025-12-02 04:29:59'),
(9, 'Tropical Paradise Short Dress', 'Playful short wedding dress with tropical-inspired lace details', 4799.00, 'dress', 'Summer Bridal', 'assets/images/products/tropical-paradise-dress.jpg', 24, 1, '2025-12-02 04:29:59', '2025-12-02 06:03:39'),
(10, 'Sunset Beach Mermaid Gown', 'Stunning mermaid silhouette gown perfect for beach weddings', 9899.00, 'gown', 'Summer Bridal', 'assets/images/products/sunset-beach-gown.jpg', 10, 1, '2025-12-02 04:29:59', '2025-12-02 04:29:59'),
(11, 'Ocean Wave A-Line Gown', 'Flowing A-line gown with soft blue undertones and pearl details', 8599.00, 'gown', 'Summer Bridal', 'assets/images/products/ocean-wave-gown.jpg', 12, 1, '2025-12-02 04:29:59', '2025-12-02 04:29:59'),
(12, 'Modern Minimalist Slip Dress', 'Sleek silk slip dress with cowl neckline for contemporary brides', 5299.00, 'dress', 'Bridal Studio', 'assets/images/products/modern-slip-dress.jpg', 20, 1, '2025-12-02 04:29:59', '2025-12-02 04:29:59'),
(13, 'Classic Grace Tea Dress', 'Timeless tea-length dress with vintage-inspired lace overlay', 6899.00, 'dress', 'Bridal Studio', 'assets/images/products/classic-grace-dress.jpg', 14, 1, '2025-12-02 04:29:59', '2025-12-02 05:09:39'),
(14, 'Timeless Cathedral Gown', 'Traditional cathedral train gown with exquisite beadwork', 14999.00, 'gown', 'Bridal Studio', 'assets/images/products/timeless-cathedral-gown.jpg', 5, 1, '2025-12-02 04:29:59', '2025-12-02 04:29:59'),
(15, 'Regal Ballroom Gown', 'Majestic ballroom gown with off-shoulder design and crystal embellishments', 16499.00, 'gown', 'Bridal Studio', 'assets/images/products/regal-ballroom-gown.jpg', 4, 1, '2025-12-02 04:29:59', '2025-12-02 04:29:59'),
(16, 'qweqw', 'qweqwe', 123.00, 'dress', 'Fall Bridal', NULL, 6, 1, '2025-12-02 06:27:20', '2025-12-02 06:27:20'),
(17, 'aaaaaa', 'aaaaa', 4343.00, 'dress', 'Bridal Studio', NULL, 23, 1, '2025-12-02 06:27:49', '2025-12-02 06:27:49'),
(18, 'anne', 'jgjgjg', 123.00, 'dress', 'Bridal Studio', NULL, 123, 1, '2025-12-02 06:29:45', '2025-12-02 06:29:45');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL CHECK (`rating` >= 1 and `rating` <= 5),
  `review_text` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `role` enum('customer','admin') DEFAULT 'customer',
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `first_name`, `last_name`, `phone`, `role`, `status`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@valora.com', '$2y$10$8foB3g07hndzRsaYFtmm7.uDNPy/rIW.kDTaxrfTCnhBZZxwvJO.e', 'Admin', 'User', NULL, 'admin', 'active', '2025-12-02 04:29:59', '2025-12-02 04:30:34'),
(2, 'jan', 'jan@gmail.com', '$2y$10$.Sa6DPJ131hiLBNUWQDXj.uTmAyC3USHUIl4R3KbruTjbrec/y/Ae', 'jan', 'jan', NULL, 'customer', 'active', '2025-12-02 04:31:24', '2025-12-02 06:02:05');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_product` (`user_id`,`product_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
