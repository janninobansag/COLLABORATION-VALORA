<?php
// dao/cart_dao.php - Cart Data Access Object

class CartDAO {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    // Get all cart items for a user
    public function getCartByUserId($user_id) {
        $query = "SELECT c.*, p.name, p.price, p.image_path, p.stock_quantity 
                  FROM cart c 
                  JOIN products p ON c.product_id = p.id 
                  WHERE c.user_id = :user_id 
                  ORDER BY c.added_at DESC";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Get cart item by ID
    public function getCartItemById($id) {
        $query = "SELECT c.*, p.name, p.price, p.image_path 
                  FROM cart c 
                  JOIN products p ON c.product_id = p.id 
                  WHERE c.id = :id";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Add item to cart
    public function addToCart($user_id, $product_id, $quantity = 1) {
        // Check if item already exists in cart
        $query = "SELECT id, quantity FROM cart WHERE user_id = :user_id AND product_id = :product_id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':product_id', $product_id);
        $stmt->execute();
        
        if ($stmt->rowCount() > 0) {
            // Item exists, update quantity
            $existing = $stmt->fetch(PDO::FETCH_ASSOC);
            return $this->updateQuantity($user_id, $product_id, $quantity + $existing['quantity']);
        } else {
            // Add new item
            $query = "INSERT INTO cart (user_id, product_id, quantity) 
                      VALUES (:user_id, :product_id, :quantity)";
            
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':user_id', $user_id);
            $stmt->bindParam(':product_id', $product_id);
            $stmt->bindParam(':quantity', $quantity);
            
            return $stmt->execute();
        }
    }

    // Update item quantity
    public function updateQuantity($user_id, $product_id, $quantity) {
        if ($quantity <= 0) {
            return $this->removeFromCart($user_id, $product_id);
        }
        
        $query = "UPDATE cart SET quantity = :quantity WHERE user_id = :user_id AND product_id = :product_id";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':product_id', $product_id);
        $stmt->bindParam(':quantity', $quantity);
        
        return $stmt->execute();
    }

    // Remove item from cart
    public function removeFromCart($user_id, $product_id) {
        $query = "DELETE FROM cart WHERE user_id = :user_id AND product_id = :product_id";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':product_id', $product_id);
        
        return $stmt->execute();
    }

    // Clear entire cart
    public function clearCart($user_id) {
        $query = "DELETE FROM cart WHERE user_id = :user_id";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        
        return $stmt->execute();
    }

    // Get cart total
    public function getCartTotal($user_id) {
        $query = "SELECT SUM(p.price * c.quantity) as total 
                  FROM cart c 
                  JOIN products p ON c.product_id = p.id 
                  WHERE c.user_id = :user_id";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $result['total'] ?? 0;
    }

    // Get cart item count (total quantity of all items)
    public function getCartItemCount($user_id) {
        $query = "SELECT COALESCE(SUM(quantity), 0) as count FROM cart WHERE user_id = :user_id";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return (int)$result['count'];
    }

    // Get unique product count in cart
    public function getCartProductCount($user_id) {
        $query = "SELECT COUNT(*) as count FROM cart WHERE user_id = :user_id";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return (int)$result['count'];
    }

    // Check if product is in cart
    public function isInCart($user_id, $product_id) {
        $query = "SELECT COUNT(*) as count FROM cart WHERE user_id = :user_id AND product_id = :product_id";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':product_id', $product_id);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $result['count'] > 0;
    }

    // Get cart with pagination
    public function getCartPaginated($user_id, $limit = 10, $offset = 0) {
        $query = "SELECT c.*, p.name, p.price, p.image_path, p.stock_quantity 
                  FROM cart c 
                  JOIN products p ON c.product_id = p.id 
                  WHERE c.user_id = :user_id 
                  ORDER BY c.added_at DESC 
                  LIMIT :limit OFFSET :offset";
        
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>